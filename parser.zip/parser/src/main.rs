// Define a custom double-ended queue (deque) data structure.
struct CustomDeque<T: Clone> {
    front: Vec<T>, // Front of the deque.
    back: Vec<T>,  // Back of the deque.
}

// Implementation of methods for the custom deque.
impl<T: Clone> CustomDeque<T> {
    // Create a new empty deque.
    fn new() -> Self {
        CustomDeque { front: Vec::new(), back: Vec::new() }
    }

    // Push an element to the front of the deque.
    fn push_front(&mut self, item: T) {
        self.front.push(item);
    }

    // Push an element to the back of the deque.
    fn push_back(&mut self, item: T) {
        self.back.push(item);
    }

    // Pop an element from the front of the deque.
    // Returns `Some(item)` if the deque is not empty, otherwise `None`.
    fn pop_front(&mut self) -> Option<T> {
        if let Some(item) = self.front.pop() {
            Some(item)
        } else if !self.back.is_empty() {
            self.front = self.back.iter().rev().cloned().collect();
            self.back.clear();
            self.front.pop()
        } else {
            None
        }
    }

    // Pop an element from the back of the deque.
    // Returns `Some(item)` if the deque is not empty, otherwise `None`.
    fn pop_back(&mut self) -> Option<T> {
        if let Some(item) = self.back.pop() {
            Some(item)
        } else if !self.front.is_empty() {
            self.back = self.front.iter().rev().cloned().collect();
            self.front.clear();
            self.back.pop()
        } else {
            None
        }
    }

    // Check if the deque is empty.
    fn is_empty(&self) -> bool {
        self.front.is_empty() && self.back.is_empty()
    }
}

// Define an enumeration to represent different arithmetic operators.
#[derive(Debug, Clone, Copy, PartialEq)]
enum Operator {
    Add,
    Subtract,
    Multiply,
    Divide,
}

// Define a function to apply an operator to two operands and return the result.
fn apply_operator(op: Operator, a: i64, b: i64) -> i64 {
    match op {
        Operator::Add => a + b,
        Operator::Subtract => b - a,
        Operator::Multiply => b * a,
        Operator::Divide => b / a,
    }
}

// Define a function to evaluate an arithmetic expression string and return the result.
fn evaluate_expression(expression: &str) -> i64 {
    // Create a new instance of the custom deque to store operands.
    let mut operands = CustomDeque::new();
    // Create a new instance of the custom deque to store operators.
    let mut operators = CustomDeque::new();
    // Define a buffer to store digits of multi-digit numbers.
    let mut num_buffer = String::new();

    // Iterate over each character in the expression string.
    for token in expression.chars() {
        match token {
            // If the token is a digit, add it to the number buffer.
            '0'..='9' => num_buffer.push(token),
            // If the token is an arithmetic operator ('a', 'b', 'c', 'd'),
            // add the parsed number from the buffer to operands and the operator to operators.
            'a' | 'b' | 'c' | 'd' => {
                if !num_buffer.is_empty() {
                    operands.push_back(num_buffer.parse::<i64>().unwrap());
                    num_buffer.clear(); // Clear the buffer.
                }
                operators.push_back(match token {
                    'a' => Operator::Add,
                    'b' => Operator::Subtract,
                    'c' => Operator::Multiply,
                    'd' => Operator::Divide,
                    _ => unreachable!(),
                });
            }
            // If the token is 'e', add an additional '+' operator to the operators deque.
            'e' => {
                operators.push_back(Operator::Add);
            }
            // If the token is 'f', apply operators until reaching an '+' operator.
            'f' => {
                while let Some(op) = operators.pop_back() {
                    if op == Operator::Add {
                        break; // Exit the loop if we encounter an addition operator.
                    }
                    // Pop the last two operands, apply the operator, and push the result back to operands.
                    if let Some(b) = operands.pop_back() {
                        if let Some(a) = operands.pop_back() {
                            let result = apply_operator(op, a, b);
                            operands.push_back(result);
                        }
                    }
                }
            }
            _ => unreachable!(), // This should never happen.
        }
    }

    // If there are digits left in the buffer, parse them and add to operands.
    if !num_buffer.is_empty() {
        operands.push_back(num_buffer.parse::<i64>().unwrap());
    }

    // Apply remaining operators to the operands deque until operators deque is empty.
    while let Some(op) = operators.pop_front() {
        if let Some(b) = operands.pop_front() {
            if let Some(a) = operands.pop_front() {
                let result = apply_operator(op, a, b);
                operands.push_front(result);
            }
        }
    }

    // Return the final result from the operands deque, or 0 if the deque is empty.
    operands.pop_front().unwrap_or(0)
}

// Unit tests for the evaluate_expression function.
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_evaluate_expression1() {
        assert_eq!(evaluate_expression("3a2c4"), 20);
    }

    #[test]
    fn test_evaluate_expression2() {
        assert_eq!(evaluate_expression("32a2d2"), 17);
    }

    #[test]
    fn test_evaluate_expression3() {
        assert_eq!(evaluate_expression("500a10b66c32"), 14208);
    }

    #[test]
    fn test_evaluate_expression4() {
        assert_eq!(evaluate_expression("3ae4c66fb32"), 235);
    }

    #[test]
    fn test_evaluate_expression5() {
        assert_eq!(evaluate_expression("3c4d2aee2a4c41fc4f"), 990);
    }
}
